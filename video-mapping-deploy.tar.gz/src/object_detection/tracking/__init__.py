"""Object tracking utilities"""
